from django.db import models
from django.contrib.auth.models import User

class Empresas(models.Model):
    id_empresa = models.AutoField(primary_key= True)
    nombre = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    def __str__(self):
        return f" {self.id_empresa}  {self.nombre}  {self.correo}"

class Clientes(models.Model):
    id_cliente = models.AutoField(primary_key= True)
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    celular = models.IntegerField()
    def __str__(self):
        return f" {self.id_cliente} {self.nombre} {self.apellido} {self.correo} {self.celular}"


class pedidos(models.Model):

    ESTADOS = (
       ('pendiente', 'Pendiente'),
        ('en_proceso', 'En Proceso'),
        ('completado', 'Completado'),
        ('cancelado', 'Cancelado'),
    )

    id_pedidos = models.AutoField(primary_key=True)
    fecha = models.DateField()
    estado = models.CharField(max_length=20, choices=ESTADOS, default= 'Pendiente')
    ubicacion = models.CharField(max_length=50)


    def __str__(self):
        return f" {self.id_pedidos} {self.fecha} {self.estado} {self.ubicacion}"





class productos(models.Model):
    id_producto = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)
    marca= models.CharField(max_length=50)
    descripcion = models.CharField(max_length=100)
    precio = models.IntegerField()
    stock = models.IntegerField()


    def __str__(self):
        return f" {self.id_producto} {self.nombre} {self.descripcion} {self.precio} {self.stock} "

class pago(models.Model):
    id_pago = models.AutoField(primary_key=True)
    fecha = models.DateField()
    hora = models.CharField(max_length=30)
    metodo_pago = models.CharField(max_length=50)
    monto= models.IntegerField()

    def __str__(self):
        return f" {self.id_pago} {self.fecha} {self.hora} {self.metodo_pago} {self.monto}"

class detalles(models.Model):
    id_detalle = models.AutoField(primary_key=True)
    cantidad = models.IntegerField()

    def __str__(self):
        return f" {self.id_detalle} {self.cantidad} "

    
class entrega(models.Model):
    id_entrega = models.AutoField(primary_key=True)
    ciudad = models.CharField(max_length=100)
    ubicacion = models.CharField(max_length=100)

    def __str__(self):
        return f" {self.id_entrega} {self.ciudad} {self.ubicacion} "
    

class Formulario(models.Model):
    id_formulario = models.AutoField(primary_key= True)
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    celular = models.IntegerField()
    motivo = models.CharField(max_length=50)
    detalles = models.CharField(max_length=100)
    fecha = models.CharField(max_length=10)
    evidencia = models.ImageField()
    def __str__(self):
        return f" {self.id_formulario} {self.nombre} {self.apellido} {self.correo} {self.celular} {self.motivo} {self.detalles} {self.fecha} {self.evidencia}"