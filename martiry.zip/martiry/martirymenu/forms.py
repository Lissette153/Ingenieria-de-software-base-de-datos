from django import forms
from .models import users
from django.contrib.auth.models import User

class usersform(forms.ModelForm):
    class Meta:
        model = users
        fields = ['id_user', 'nombre', 'apellido', 'correo','celular', 'rol']


class UserEditForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']
