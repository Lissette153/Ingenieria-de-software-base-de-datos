from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .models import productos, pago, Clientes, Empresas, Formulario
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.http import HttpResponse
from django.template import loader
from .models import Clientes

# Create your views here.
def index(request):
    return render(request, 'login/index.html')


def register(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        apellido = request.POST['apellido']
        celular = request.POST['celular']
        correo = request.POST['correo']
        password = request.POST['password']
        re_password = request.POST['re-password']

        # Verificar si las contraseñas coinciden
        if password != re_password:
            messages.error(request, 'Las contraseñas no coinciden')
            return redirect('/register')

        # Crear un nuevo usuario
        user = User.objects.create_user(username=correo, email=correo, password=password)
        
        # Crear un nuevo cliente asociado al usuario
        cliente = Clientes.objects.create(nombre=nombre, apellido=apellido, celular=celular, correo=correo)

        messages.success(request, 'Registro exitoso. Por favor, inicie sesión.')
        return redirect('/login')

    return render(request, 'login/register.html')


def login_view(request):
    if request.method == 'POST':
        correo = request.POST['correo']
        contraseña = request.POST['contraseña']

        # Autenticar al usuario
        user = authenticate(request, username=correo, password=contraseña)

        if user is not None:
            login(request, user)
            messages.success(request, 'Inicio de sesión exitoso.')
            return redirect('/dashboard')  # Reemplaza 'inicio' con el nombre de tu vista de inicio

        else:
            messages.error(request, 'Credenciales incorrectas. Por favor, intente nuevamente.')
            return redirect('/login')

    return render(request, 'login/login.html')

def logout_view(request):
    logout(request)
    return redirect('/')

def galeria_herramientas(request):
    list_productos = productos.objects.all()
    return render(request, 'web/herramientas.html', {'productos': list_productos})

def pago_productos(request, id_pago=None):
    if id_pago:
        pago_productos = get_object_or_404(pago, id=id_pago)
        return render(request, 'web/pago.html', {'pago': pago_productos})
    else:
        # Lógica para manejar el caso sin id_pago
        return render(request, 'web/pago.html', {'mensaje': 'No se proporcionó un ID de pago'})
    
def pagofinal(request, id_pago=None):
    if id_pago:
        pagofinal = get_object_or_404(pago, id=id_pago)
        return render(request, 'web/pagofinal.html', {'pago': pagofinal})
    else:
        # Lógica para manejar el caso sin id_pago
        return render(request, 'web/pagofinal.html', {'mensaje': 'No se proporcionó un ID de pago'})
    
    
def dashboard(request):
    clientes = Clientes.objects.all()
    data = {'usuarios': clientes}
    #adicionar vistas y la tabla user comparar id_usuario si es el mismo y si fuera el mismo recuperar datos propios, como personalizar la clase y crear su propio auth_user, con la id_rol 
    return render(request, 'login/dashboard.html', data)


def formulario(request):
    return render(request, 'login/formulario.html')

def confirmacion(request):
    return render(request, 'web/confirmacion.html')

def enviar(request):
    return render(request, 'web/enviar.html')


def buscar_productos(request):
    resultados = []
    query = request.GET.get("id_productos")
    if query:
        resultados = productos.objects.filter(id_productos=query)

    return render(request, 'web/buscar_productos.html', {'resultados': resultados})

def terminos(request):
    return render(request, 'login/terminos.html')

def promesa(request):
    return render(request, 'login/promesa.html')