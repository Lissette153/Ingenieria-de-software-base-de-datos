
from django.contrib import admin
from django.urls import path
from martirymenu import views

urlpatterns = [
    path('', views.index),
    path('register/', views.register),
    path('login/', views.login_view, name='login_view'),
    path('logout/', views.logout_view),
    path('herramientas/', views.galeria_herramientas, name='herramientas'),
    path('pago/', views.pago_productos, name= 'pago'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('pagofinal/', views.pagofinal, name='pagofinal'),
    path('formulario/', views.formulario, name= 'formulario'),
    path('confirmacion/', views.confirmacion, name= 'confirmacion'),
    path('enviar/', views.enviar, name= 'enviar'),
    path('buscar_productos/', views.buscar_productos, name='buscar_productos'),
    path('terminos/', views.terminos, name= 'terminos'),
    path('promesa/', views.promesa, name= 'promesa'),
]
